// The Core BCI - Static Site JavaScript - Fixed Version

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all functionality
    initializeNavigation();
    initializeMobileMenu();
    initializeScrollEffects();
    initializeContactForm();
    initializeAnimations();
    initializeScrollProgress();
    initializeCTAButtons();
    initializeSocialLinks();
    initializeKeyboardNavigation();
    handleWindowResize();
    initializeErrorHandling();
});

/**
 * Initialize navigation functionality
 */
function initializeNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    const sections = document.querySelectorAll('section[id]');
    
    // Smooth scroll to sections
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Nav link clicked:', this.getAttribute('href'));
            
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            if (targetSection) {
                const navbar = document.getElementById('navbar');
                const navbarHeight = navbar ? navbar.offsetHeight : 80;
                const offsetTop = targetSection.offsetTop - navbarHeight;
                
                // Use native smooth scrolling
                targetSection.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
                
                // Close mobile menu if open
                closeMobileMenu();
                
                // Update active link immediately
                updateActiveNavLink(targetId);
            }
        });
    });
    
    // Highlight active navigation link on scroll
    window.addEventListener('scroll', throttle(function() {
        updateActiveNavLinkOnScroll();
    }, 100));
}

/**
 * Update active navigation link
 */
function updateActiveNavLink(targetId) {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === targetId) {
            link.classList.add('active');
        }
    });
}

/**
 * Update active navigation link on scroll
 */
function updateActiveNavLinkOnScroll() {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-link');
    let current = '';
    const navbar = document.getElementById('navbar');
    const navbarHeight = navbar ? navbar.offsetHeight : 80;
    
    sections.forEach(section => {
        const sectionTop = section.offsetTop - navbarHeight - 50;
        const sectionHeight = section.clientHeight;
        
        if (window.pageYOffset >= sectionTop && 
            window.pageYOffset < sectionTop + sectionHeight) {
            current = section.getAttribute('id');
        }
    });
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === '#' + current) {
            link.classList.add('active');
        }
    });
}

/**
 * Initialize CTA buttons in hero section
 */
function initializeCTAButtons() {
    const ctaButtons = document.querySelectorAll('.hero-buttons .btn');
    
    ctaButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('CTA button clicked:', this.getAttribute('href'));
            
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            if (targetSection) {
                // Use native smooth scrolling
                targetSection.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
                
                // Update active nav link
                updateActiveNavLink(targetId);
                showNotification(`Navigating to ${targetId.replace('#', '').toUpperCase()} section`, 'info');
            }
        });
    });
}

/**
 * Initialize social media links
 */
function initializeSocialLinks() {
    const socialLinks = document.querySelectorAll('.social-link, .footer-social a');
    
    socialLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Social link clicked:', this.textContent);
            
            const platform = this.textContent.toLowerCase().trim();
            showNotification(`${platform.charAt(0).toUpperCase() + platform.slice(1)} link clicked! This would open the social media page.`, 'info');
        });
    });
}

/**
 * Initialize mobile menu functionality
 */
function initializeMobileMenu() {
    const hamburger = document.getElementById('hamburger');
    const navMenu = document.getElementById('nav-menu');
    
    if (!hamburger || !navMenu) {
        console.warn('Hamburger or nav menu not found');
        return;
    }
    
    console.log('Mobile menu initialized');
    
    hamburger.addEventListener('click', function(e) {
        e.stopPropagation();
        console.log('Hamburger clicked');
        
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
        
        // Add/remove body class to prevent scrolling when menu is open
        if (navMenu.classList.contains('active')) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = '';
        }
    });
    
    // Close menu when clicking outside
    document.addEventListener('click', function(e) {
        if (!hamburger.contains(e.target) && !navMenu.contains(e.target)) {
            closeMobileMenu();
        }
    });
    
    // Close menu on window resize if screen becomes large
    window.addEventListener('resize', function() {
        if (window.innerWidth > 768) {
            closeMobileMenu();
        }
    });
}

/**
 * Close mobile menu
 */
function closeMobileMenu() {
    const hamburger = document.getElementById('hamburger');
    const navMenu = document.getElementById('nav-menu');
    
    if (hamburger && navMenu) {
        hamburger.classList.remove('active');
        navMenu.classList.remove('active');
        document.body.style.overflow = '';
    }
}

/**
 * Initialize scroll effects
 */
function initializeScrollEffects() {
    const navbar = document.getElementById('navbar');
    
    if (!navbar) return;
    
    window.addEventListener('scroll', throttle(function() {
        if (window.scrollY > 100) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    }, 100));
}

/**
 * Initialize contact form functionality
 */
function initializeContactForm() {
    const contactForm = document.getElementById('contact-form');
    
    if (!contactForm) {
        console.warn('Contact form not found');
        return;
    }
    
    console.log('Contact form initialized');
    
    // Add real-time validation
    const inputs = contactForm.querySelectorAll('input, textarea');
    inputs.forEach(input => {
        input.addEventListener('blur', function() {
            validateField(this);
        });
        
        input.addEventListener('input', function() {
            // Clear any previous error state on input
            clearFieldError(this);
        });
    });
    
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        console.log('Form submitted');
        
        // Get form data
        const formData = new FormData(contactForm);
        const name = formData.get('name') ? formData.get('name').trim() : '';
        const email = formData.get('email') ? formData.get('email').trim() : '';
        const subject = formData.get('subject') ? formData.get('subject').trim() : '';
        const message = formData.get('message') ? formData.get('message').trim() : '';
        
        console.log('Form data:', { name, email, subject, message });
        
        // Validate form
        const validation = validateContactForm(name, email, subject, message);
        
        if (!validation.isValid) {
            showNotification(validation.message, 'error');
            // Focus on first invalid field
            const firstInvalidField = contactForm.querySelector('.form-control.error');
            if (firstInvalidField) {
                firstInvalidField.focus();
            }
            return;
        }
        
        // Submit form
        submitContactForm(contactForm, { name, email, subject, message });
    });
}

/**
 * Validate individual field
 */
function validateField(field) {
    const value = field.value.trim();
    let isValid = true;
    let errorMessage = '';
    
    switch (field.type) {
        case 'email':
            isValid = value && isValidEmail(value);
            errorMessage = !value ? 'Email is required' : 'Please enter a valid email address';
            break;
        case 'text':
            if (field.name === 'name') {
                isValid = value && value.length >= 2;
                errorMessage = !value ? 'Name is required' : 'Name must be at least 2 characters';
            } else if (field.name === 'subject') {
                isValid = value && value.length >= 3;
                errorMessage = !value ? 'Subject is required' : 'Subject must be at least 3 characters';
            }
            break;
        case 'textarea':
            isValid = value && value.length >= 10;
            errorMessage = !value ? 'Message is required' : 'Message must be at least 10 characters';
            break;
    }
    
    if (!isValid) {
        setFieldError(field, errorMessage);
    } else {
        clearFieldError(field);
    }
    
    return isValid;
}

/**
 * Set field error state
 */
function setFieldError(field, message) {
    field.classList.add('error');
    field.style.borderColor = '#dc2626';
    
    // Remove existing error message
    const existingError = field.parentNode.querySelector('.field-error');
    if (existingError) {
        existingError.remove();
    }
    
    // Add error message
    const errorElement = document.createElement('div');
    errorElement.className = 'field-error';
    errorElement.textContent = message;
    errorElement.style.cssText = `
        color: #dc2626;
        font-size: 12px;
        margin-top: 4px;
        display: block;
    `;
    field.parentNode.appendChild(errorElement);
}

/**
 * Clear field error state
 */
function clearFieldError(field) {
    field.classList.remove('error');
    field.style.borderColor = '';
    
    const errorElement = field.parentNode.querySelector('.field-error');
    if (errorElement) {
        errorElement.remove();
    }
}

/**
 * Validate contact form data
 */
function validateContactForm(name, email, subject, message) {
    if (!name) {
        return { isValid: false, message: 'Please enter your name.' };
    }
    
    if (name.length < 2) {
        return { isValid: false, message: 'Name must be at least 2 characters long.' };
    }
    
    if (!email) {
        return { isValid: false, message: 'Please enter your email address.' };
    }
    
    if (!isValidEmail(email)) {
        return { isValid: false, message: 'Please enter a valid email address.' };
    }
    
    if (!subject) {
        return { isValid: false, message: 'Please enter a subject.' };
    }
    
    if (subject.length < 3) {
        return { isValid: false, message: 'Subject must be at least 3 characters long.' };
    }
    
    if (!message) {
        return { isValid: false, message: 'Please enter your message.' };
    }
    
    if (message.length < 10) {
        return { isValid: false, message: 'Message must be at least 10 characters long.' };
    }
    
    return { isValid: true };
}

/**
 * Submit contact form
 */
function submitContactForm(form, data) {
    const submitButton = form.querySelector('button[type="submit"]');
    const originalText = submitButton.textContent;
    
    // Show loading state
    submitButton.textContent = 'Sending...';
    submitButton.disabled = true;
    submitButton.style.opacity = '0.7';
    
    console.log('Submitting form with data:', data);
    
    // Simulate form processing (2 second delay)
    setTimeout(() => {
        showNotification('Thank you for your message! We\'ll get back to you soon.', 'success');
        form.reset();
        
        // Clear any field errors
        const errorElements = form.querySelectorAll('.field-error');
        errorElements.forEach(el => el.remove());
        
        const fields = form.querySelectorAll('.form-control');
        fields.forEach(field => {
            field.classList.remove('error');
            field.style.borderColor = '';
        });
        
        // Reset button
        submitButton.textContent = originalText;
        submitButton.disabled = false;
        submitButton.style.opacity = '1';
        
        console.log('Form submitted successfully');
        
    }, 2000);
}

/**
 * Validate email format
 */
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

/**
 * Initialize animations
 */
function initializeAnimations() {
    // Create intersection observer for fade-in animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate');
            }
        });
    }, observerOptions);
    
    // Observe elements for animation
    const animationElements = [
        '.section-header',
        '.hero-content',
        '.about-description',
        '.stat-item',
        '.service-card',
        '.work-card',
        '.testimonial-content',
        '.contact-content'
    ];
    
    animationElements.forEach(selector => {
        const elements = document.querySelectorAll(selector);
        elements.forEach(el => {
            el.classList.add('fade-in-up');
            observer.observe(el);
        });
    });
    
    // Stagger animation for grid items
    const gridContainers = ['.stats-grid', '.services-grid', '.works-grid'];
    
    gridContainers.forEach(selector => {
        const container = document.querySelector(selector);
        if (container) {
            const items = container.children;
            Array.from(items).forEach((item, index) => {
                item.classList.add('fade-in-up');
                item.style.transitionDelay = `${index * 0.1}s`;
                observer.observe(item);
            });
        }
    });
    
    // Add hover effects to cards
    addCardHoverEffects();
}

/**
 * Add hover effects to cards
 */
function addCardHoverEffects() {
    const cards = document.querySelectorAll('.service-card, .work-card');
    
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-8px)';
            this.style.transition = 'transform 0.3s ease';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
}

/**
 * Initialize scroll progress indicator
 */
function initializeScrollProgress() {
    // Create scroll progress bar
    const progressBar = document.createElement('div');
    progressBar.className = 'scroll-indicator';
    document.body.appendChild(progressBar);
    
    window.addEventListener('scroll', throttle(updateScrollProgress, 16));
    
    function updateScrollProgress() {
        const scrollTop = window.pageYOffset;
        const docHeight = document.body.scrollHeight - window.innerHeight;
        const scrollPercent = docHeight > 0 ? (scrollTop / docHeight) : 0;
        
        progressBar.style.transform = `scaleX(${Math.min(Math.max(scrollPercent, 0), 1)})`;
    }
}

/**
 * Show notification
 */
function showNotification(message, type = 'info') {
    console.log(`Notification: ${type} - ${message}`);
    
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => {
        notification.remove();
    });
    
    // Create notification
    const notification = document.createElement('div');
    notification.className = `notification notification--${type}`;
    
    notification.innerHTML = `
        <div class="notification-content">
            <span class="notification-message">${message}</span>
            <button class="notification-close" type="button">&times;</button>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Show notification
    setTimeout(() => {
        notification.classList.add('show');
    }, 100);
    
    // Auto hide after 5 seconds
    const autoHideTimeout = setTimeout(() => {
        hideNotification(notification);
    }, 5000);
    
    // Manual close
    const closeButton = notification.querySelector('.notification-close');
    closeButton.addEventListener('click', () => {
        clearTimeout(autoHideTimeout);
        hideNotification(notification);
    });
}

/**
 * Hide notification
 */
function hideNotification(notification) {
    notification.classList.remove('show');
    setTimeout(() => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    }, 300);
}

/**
 * Utility function to throttle function calls
 */
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

/**
 * Initialize keyboard navigation for accessibility
 */
function initializeKeyboardNavigation() {
    document.addEventListener('keydown', function(e) {
        // Enhanced tab navigation
        if (e.key === 'Tab') {
            document.body.classList.add('keyboard-navigation');
        }
        
        // Escape key to close mobile menu
        if (e.key === 'Escape') {
            closeMobileMenu();
        }
    });
    
    // Remove keyboard navigation class on mouse use
    document.addEventListener('mousedown', function() {
        document.body.classList.remove('keyboard-navigation');
    });
}

/**
 * Handle window resize for responsive updates
 */
function handleWindowResize() {
    window.addEventListener('resize', throttle(() => {
        // Close mobile menu on resize to larger screen
        if (window.innerWidth > 768) {
            closeMobileMenu();
        }
    }, 250));
}

/**
 * Initialize error handling
 */
function initializeErrorHandling() {
    window.addEventListener('error', function(e) {
        console.error('Application error:', e.error);
    });
    
    // Handle unhandled promise rejections
    window.addEventListener('unhandledrejection', function(e) {
        console.error('Unhandled promise rejection:', e.reason);
        e.preventDefault();
    });
}

// Handle page load
window.addEventListener('load', function() {
    // Remove any loading states
    document.body.classList.add('loaded');
    
    // Initialize scroll position if there's a hash
    if (window.location.hash) {
        setTimeout(() => {
            const target = document.querySelector(window.location.hash);
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
                updateActiveNavLink(window.location.hash);
            }
        }, 100);
    }
    
    console.log('The Core BCI static site loaded successfully');
});